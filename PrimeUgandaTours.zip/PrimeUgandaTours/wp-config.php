<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'PrimeUgandaTours' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '5@..*+|5a+Q59;<5gYa `}NIX.Q5w_,Z<c=*:-xv{$b4S]pv`@gkU5AxML~uer#G' );
define( 'SECURE_AUTH_KEY',  'QKxgkRuWj0=EiSJ-ehy<R-2Tst,N!GM{r5M^u0*rb6:h6_R&Fgd9v/ZCq5BSjq9%' );
define( 'LOGGED_IN_KEY',    'eQ[|^.}/TL`1tU&:^~-nw~B~DN%5)`W]I&^reMNqKxZu95=rrIM3^h,VZbF^QzQ`' );
define( 'NONCE_KEY',        'i~r[1@l0Z:t,Z|5[OJPf2EBFzQ0>>1[=.R=^;ZW5dBi5_mAD!sJr>{YWh0dWuChX' );
define( 'AUTH_SALT',        '2%w.VFA]TJfg5M@7,/@l(#zq=;2<uC}3y@0!O_/u_T, Blzo$8,-h#9v4)mON/Xr' );
define( 'SECURE_AUTH_SALT', 'X5}WMIJ;A~mwHCrOiF`y))|bT2&A-fE_z8<e&Ct39JXCwq%X<7wMn|t;3WoX:/VV' );
define( 'LOGGED_IN_SALT',   'Ww-ku?Z(8Ff(LriIQ@>71?[2%[jLNim~71]Rw@m0o9)?w;X~P35Js.+W_mFz8[?d' );
define( 'NONCE_SALT',       'KPUiraPO*I=TUb_`N*j%t,w8Zb-0:=BHy=s0dtw~[ j[azEt@)6HR6oO`MwK?XCW' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
