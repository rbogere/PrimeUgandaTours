<div class="navbar">
   <div class="navbar-inner">
       <a id="logo" href="/">Single Malt</a>
       <ul class="nav">
           <li><a href="/">Home</a></li>
           <li><a href="/contact">Contact</a></li>
       </ul>
   </div>
</div>